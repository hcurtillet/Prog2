#ifndef _FONCTIONS
#define _FONCTIONS

char* double2string(double x, char* s);
char* string_operation(char* a1,char* sv, char op);
#endif
